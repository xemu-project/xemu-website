Running xemu_local_dumps.reg will create the following registry key:

    HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps\xemu.exe

If xemu crashes after starting, Windows will produce a dump at %LOCALAPPDATA%\CrashDumps
